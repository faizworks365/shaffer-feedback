"use client";

import { FormEvent, useMemo, useState } from "react";

type Answers = {
  email: string;
  name: string;
  contact: string;
  overall: string;
  staff: string;
  changingCleanliness: string;
  mirrors: string;
  changingComfort: string;
  sittingCleanliness: string;
  waitingComfort: string;
  foundProduct: string;
  visitAgain: string;
  suggestions: string;
};

const initialAnswers: Answers = {
  email: "", name: "", contact: "", overall: "", staff: "",
  changingCleanliness: "", mirrors: "", changingComfort: "",
  sittingCleanliness: "", waitingComfort: "", foundProduct: "",
  visitAgain: "", suggestions: "",
};

const steps = [
  { eyebrow: "Welcome", title: "Your details", intro: "Tell us a little about yourself before we begin." },
  { eyebrow: "Outlet experience", title: "Your visit", intro: "Please share your overall experience, including service quality and staff interaction." },
  { eyebrow: "Changing room", title: "Comfort in every detail", intro: "Kindly share your feedback on the cleanliness, ambience and overall comfort of our changing room facilities." },
  { eyebrow: "Sitting area", title: "A considered pause", intro: "We’d love your feedback on how comfortable and relaxing our seating area felt during your visit." },
  { eyebrow: "Product & service", title: "One final thought", intro: "We’d love to hear your thoughts on our product selection, sizing availability and the service you received." },
];

const RadioGroup = ({ label, name, options, value, onChange }: { label: string; name: keyof Answers; options: string[]; value: string; onChange: (name: keyof Answers, value: string) => void }) => (
  <fieldset className="question">
    <legend>{label}</legend>
    <div className={`choices ${options.length === 5 ? "scale" : ""}`}>
      {options.map((option) => (
        <label className="choice" key={option}>
          <input type="radio" name={name} value={option} checked={value === option} onChange={() => onChange(name, option)} />
          <span className="radio-mark" />
          <span>{option}</span>
        </label>
      ))}
    </div>
  </fieldset>
);

export default function Home() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Answers>(initialAnswers);
  const [errors, setErrors] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");

  const requiredByStep: (keyof Answers)[][] = useMemo(() => [
    ["email", "name", "contact"], ["overall", "staff"],
    ["changingCleanliness", "mirrors", "changingComfort"],
    ["sittingCleanliness", "waitingComfort"], ["foundProduct", "visitAgain"],
  ], []);

  const update = (name: keyof Answers, value: string) => {
    setAnswers((current) => ({ ...current, [name]: value }));
    setErrors((current) => current.filter((item) => item !== name));
  };

  const validate = () => {
    const missing = requiredByStep[step].filter((key) => !answers[key].trim());
    if (step === 0 && answers.email && !/^\S+@\S+\.\S+$/.test(answers.email)) missing.push("email");
    setErrors([...new Set(missing)]);
    return missing.length === 0;
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!validate()) return;
    setErrors([]);
    if (step < 4) {
      setStep((current) => current + 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    setSubmitting(true);
    setSubmitError("");
    try {
      const response = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(answers),
      });
      const result = await response.json();
      if (!response.ok || !result.success) throw new Error(result.error);
      setSubmitted(true);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      setSubmitError("We couldn’t save your feedback. Please check your connection and try again.");
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return <main className="site-shell success-shell"><header className="topbar"><a className="wordmark" href="https://shaffer.store">SHAFFER</a><span>Customer care</span></header><section className="success-card"><span className="success-mark">✓</span><p className="eyebrow">Feedback received</p><h1>Thank you for helping us refine the experience.</h1><p>Your perspective matters to us. We look forward to welcoming you back to SHAFFER.</p><button onClick={() => { setAnswers(initialAnswers); setStep(0); setSubmitted(false); }}>Submit another response <span>→</span></button><a href="https://shaffer.store">Return to shaffer.store</a></section></main>;
  }

  return (
    <main className="site-shell">
      <header className="topbar"><a className="wordmark" href="https://shaffer.store">SHAFFER</a><div><span>Customer care</span><i /><span>{String(step + 1).padStart(2, "0")} / 05</span></div></header>
      <div className="experience-grid">
        <aside className="story-panel">
          <div className="story-copy"><p className="eyebrow">SHAFFER customer experience</p><h1>Your experience,<br />refined.</h1><span className="gold-line" /><p>At SHAFFER, every detail matters. Share your visit with us and help shape an even more considered experience.</p></div>
        </aside>
        <section className="form-wrap">
          <form className="form-card" onSubmit={submit} noValidate>
            <div className="form-heading"><div><p className="eyebrow">{steps[step].eyebrow}</p><h2>{steps[step].title}</h2><p>{steps[step].intro}</p></div><div className="progress-meta"><span>Step {String(step + 1).padStart(2, "0")} of 05</span><div className="progress-track">{steps.map((_, index) => <i key={index} className={index <= step ? "active" : ""} />)}</div></div></div>
            <div className="questions" key={step}>
              {step === 0 && <>
                <label className={errors.includes("email") ? "field error" : "field"}>Email address<input type="email" value={answers.email} onChange={(e) => update("email", e.target.value)} placeholder="Enter your email" autoComplete="email" /><small>Please enter a valid email address.</small></label>
                <label className={errors.includes("name") ? "field error" : "field"}>Name<input value={answers.name} onChange={(e) => update("name", e.target.value)} placeholder="Enter your name" autoComplete="name" /><small>This field is required.</small></label>
                <label className={errors.includes("contact") ? "field error" : "field"}>Contact number<input type="tel" value={answers.contact} onChange={(e) => update("contact", e.target.value)} placeholder="Enter your contact number" autoComplete="tel" /><small>This field is required.</small></label>
              </>}
              {step === 1 && <><RadioGroup label="How would you rate your overall experience at our outlet?" name="overall" options={["Excellent", "Good", "Fair", "Poor"]} value={answers.overall} onChange={update} /><RadioGroup label="How would you rate the behavior and assistance of our staff?" name="staff" options={["Excellent", "Good", "Fair", "Poor"]} value={answers.staff} onChange={update} /></>}
              {step === 2 && <><RadioGroup label="How would you rate the cleanliness of the changing room?" name="changingCleanliness" options={["Excellent", "Good", "Fair", "Poor"]} value={answers.changingCleanliness} onChange={update} /><RadioGroup label="Were the lighting and mirrors satisfactory?" name="mirrors" options={["Yes", "No"]} value={answers.mirrors} onChange={update} /><RadioGroup label="Was the changing room comfortable and well-maintained?" name="changingComfort" options={["Yes", "No"]} value={answers.changingComfort} onChange={update} /></>}
              {step === 3 && <><RadioGroup label="How would you rate the cleanliness and comfort of the sitting area?" name="sittingCleanliness" options={["Excellent", "Good", "Fair", "Poor"]} value={answers.sittingCleanliness} onChange={update} /><RadioGroup label="How comfortable was your experience while waiting in our seating area?" name="waitingComfort" options={["1", "2", "3", "4", "5"]} value={answers.waitingComfort} onChange={update} /></>}
              {step === 4 && <><RadioGroup label="Were you able to find your desired product or size easily?" name="foundProduct" options={["Yes", "No"]} value={answers.foundProduct} onChange={update} /><RadioGroup label="Would you like to visit our outlet again?" name="visitAgain" options={["Yes", "No"]} value={answers.visitAgain} onChange={update} /><label className="field">How can we further refine and enhance your overall service experience?<textarea value={answers.suggestions} onChange={(e) => update("suggestions", e.target.value)} placeholder="Share your suggestions (optional)" /></label></>}
            </div>
            {errors.length > 0 && <p className="form-error" role="alert">Please complete the required question{errors.length > 1 ? "s" : ""} before continuing.</p>}
            {submitError && <p className="submit-error" role="alert">{submitError}</p>}
            <div className="form-actions">{step > 0 && <button className="back" type="button" disabled={submitting} onClick={() => { setErrors([]); setSubmitError(""); setStep((current) => current - 1); }}>← Back</button>}<button className="continue" type="submit" disabled={submitting}>{submitting ? "Saving feedback…" : step === 4 ? "Submit feedback" : "Continue"}<span>{submitting ? "" : "→"}</span></button></div>
          </form>
          <p className="privacy">Your feedback is used only to improve your SHAFFER experience.</p>
        </section>
      </div>
    </main>
  );
}

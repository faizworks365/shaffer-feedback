const GOOGLE_SCRIPT_URL =
  "https://script.google.com/macros/s/AKfycbyiGsKHSTXGGTmIzOU5zlG_L6ayB_L6yQS300FYlXk3BmCu-5_u0Zsw7k-RlXxDQat7pQ/exec";

export async function POST(request: Request) {
  try {
    const feedback = await request.json();

    const googleResponse = await fetch(GOOGLE_SCRIPT_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(feedback),
      redirect: "follow",
      cache: "no-store",
    });

    if (!googleResponse.ok) {
      throw new Error(`Google Sheets returned ${googleResponse.status}`);
    }

    const result = await googleResponse.json();
    if (!result.success) {
      throw new Error(result.error || "Google Sheets rejected the response.");
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error("Feedback submission failed:", error);
    return Response.json(
      { success: false, error: "We couldn't save your feedback. Please try again." },
      { status: 500 },
    );
  }
}
